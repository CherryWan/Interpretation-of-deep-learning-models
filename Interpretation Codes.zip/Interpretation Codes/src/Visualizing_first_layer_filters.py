import numpy as np
import cv2
from torchvision import models

if __name__ == '__main__':
    filter = 5 # choose the filter to be visualized
    pretrained_model = models.alexnet(pretrained=True)  # use the pretrained Alexnet model

    weights_keys = pretrained_model.state_dict().keys()

    for key in weights_keys:
        # remove num_batches_tracked para(in bn)
        if "bias" in key:
            continue
        if "classifier" in key:
            continue

        if "features.0.weight" in key:
            weight_t = pretrained_model.state_dict()[key].numpy()

            # read a kernel information
            k = weight_t[filter, :, :, :]
            k_image = k.transpose(1,2,0)
            # save the matrix of the filter as an image
            cv2.imwrite("../results/Filter_"+str(filter)+'_'+str(key)+'.jpg', np.uint8(255 * k_image))

