from __future__ import print_function
from __future__ import division
import numpy as np
import matplotlib.pyplot as plt
import pickle
from sklearn.manifold import TSNE

def drawtsne():
    # As the feature file is too large to be included in the package, we did not put the feature file in the package. You can use your own feature file.
    with open('..data/deep_features', 'rb') as mysavedata:
        features = pickle.load(mysavedata)
    for i in range(29, 30):
        s_train = np.array(features['epoch' + str(i) + 'train'])  # Get the features for training dataset
        s_test = np.array(features['epoch' + str(i) + 'test'])  # Get the features for testing dataset
        res = np.vstack((s_train, s_test))

        lable_train = np.array(features['Lepoch' + str(i) + 'train'])  # Get the lables for training dataset
        lable_test = np.array(features['Lepoch' + str(i) + 'test'])  # Get the lables for testing dataset
        lable = np.hstack((lable_train, lable_test))

        # conduct dimension reduction using t-SNE( into 3-D space)
        tsne = TSNE(n_components=3, init='pca', random_state=501)
        X_tsne = tsne.fit_transform(res)

        X_r = [[[], [], []], [[], [], []]]
        for j in range(len(lable)):
            X_r[lable[j]][0].append(X_tsne[j][0])
            X_r[lable[j]][1].append(X_tsne[j][1])
            X_r[lable[j]][2].append(X_tsne[j][2])
            classes = ['Without COVID-19 Lesion', 'With COVID-19 Lesion']
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        for label in [0, 1]:
            ax.scatter(X_r[label][0], X_r[label][1], X_r[label][2], s=10, alpha=.8, lw=2,label=classes[label])
        plt.legend(loc='best')
        plt.title('t-SNE ')
        plt.show()


if __name__ == '__main__':
    drawtsne()
