import matplotlib.pyplot as plt
from sklearn.decomposition import PCA, KernelPCA
import numpy as np
import pickle

def pca_plt(X, y):
    # conduct dimension reduction using PCA( into 3-D space)
    pca = PCA(n_components=3)
    X = pca.fit(X).transform(X)
    X_r = [[[], [],[]], [[], [],[]]]
    for i in range(len(y)):
        X_r[y[i]][0].append(X[i][0])
        X_r[y[i]][1].append(X[i][1])
        X_r[y[i]][2].append(X[i][2])

    # draw the scatter diagram
    plt.figure()
    lw = 2
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    for i, target_name in zip([0, 1], ['Without COVID-19 Lesion', 'With COVID-19 Lesion']):
        ax.scatter(X_r[i][0], X_r[i][1],X_r[i][2],s=10, alpha=.8, lw=lw,
                    label=target_name)
    plt.legend(loc='best', shadow=False, scatterpoints=1)
    plt.title('PCA')
    plt.show()


def plot_KPCA(X_orig, y):
    # KPCA with four kernels: linear, poly, rbf and sigmoid
    for j, kernel in enumerate(['linear', 'poly', 'rbf', 'sigmoid']):
        kpca = KernelPCA(n_components=3, kernel=kernel)
        X = kpca.fit(X_orig).transform(X_orig)

        X_r = [[[], [],[]], [[], [],[]]]
        for i in range(len(y)):
            X_r[y[i]][0].append(X[i][0])
            X_r[y[i]][1].append(X[i][1])
            X_r[y[i]][2].append(X[i][2])

        classes = ['Without COVID-19 Lesion', 'With COVID-19 Lesion']
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        for label in [0, 1]:
            ax.scatter(X_r[label][0], X_r[label][1],X_r[label][2] ,s=10, alpha=.8, lw=2,label=classes[label])
            plt.legend(loc='best')
            plt.title('KPCA with kernel ' + kernel)
        plt.show()


if __name__ == '__main__':
    # As the feature file is too large to be included in the package, we did not put the feature file in the package. You can use your own feature file.
    with open('..data/deep_features', 'rb') as mysavedata:
        features = pickle.load(mysavedata)
    for i in range(29, 30):
        s_train = np.array(features['epoch' + str(i) + 'train'])  # Get the features for training dataset
        s_test = np.array(features['epoch' + str(i) + 'test'])  # Get the features for testing dataset
        res = np.vstack((s_train, s_test))

        lable_train = np.array(features['Lepoch' + str(i) + 'train'])  # Get the lables for training dataset
        lable_test = np.array(features['Lepoch' + str(i) + 'test'])  # Get the lables for testing dataset
        lable = np.hstack((lable_train, lable_test))
        pca_plt(res, lable)
        plot_KPCA(res, lable)

